<?= $this->extend("template_dashboard/layout"); ?>
<?= $this->section("content"); ?>
<main>
    <div class="container-fluid px-4">
        <h1 class="mt-4 mb-4"><?= $title; ?></h1>
        <?php
        if ($flashdata != null) {
            echo $flashdata;
        }; ?>
        <div class="row">
            <div class="col-xl-12 col-md-12">
                <div class="table-responsive">
                    <table class="table table-dark table-striped" id="myTable">
                        <thead>
                            <tr>
                                <th scope="col">No</th>
                                <th scope="col">Kode Order</th>
                                <th scope="col">Tanggal Pesan</th>
                                <th scope="col">Tanggal Deadline</th>
                                <th scope="col">Project By</th>
                                <th scope="col">Tambahan</th>
                                <th scope="col">Proses</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $i = 1;
                            foreach ($status as $row) : ?>
                                <tr class="table-secondary">
                                    <th scope="row"><?= $i; ?></th>
                                    <td><?= $row["order_code"]; ?></td>
                                    <td><?= $row["order_date"]; ?></td>
                                    <td><?= $row["deadline"]; ?></td>
                                    <td><?php if ($row["waterproof"] != null) {
                                            echo "Waterproof, ";
                                            echo "<br>";
                                        }
                                        if ($row["adhesive"] != null) {
                                            echo "Perekat =  " . $row['adhesive'] . ",";
                                            echo "<br>";
                                        }
                                        if ($row["switch"] != null) {
                                            echo "Saklar = " . $row['switch'] . ",";
                                            echo "<br>";
                                        }
                                        if ($row["laser_cut"] != null) {
                                            echo "Laser Cut,";
                                            echo "<br>";
                                        }
                                        if ($row["peniklan"] != null) {
                                            echo "Peniklan = " . $row['peniklan'];
                                            echo "<br>";
                                        }
                                        ?></td>
                                    <td><?= $row["fullname"]; ?></td>

                                    <td><a type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modal_update_status<?= $row['id_order'] ?>">Update Status</a></td>

                                </tr>


                                <!-- Modal -->
                                <div class="modal fade" id="modal_update_status<?= $row['id_order'] ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                    <div class="modal-dialog modal-dialog-centered">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="exampleModalLabel">Gambar Desain Lampu</h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                            </div>
                                            <form action="/update-status-checkout" method="POST" enctype="multipart/form-data">
                                                <div class="modal-body">

                                                    <div class="col-md-12 mb-3">
                                                        <label for="image" class="form-label">Upload Gambar Checkout</label>
                                                        <input type="hidden" name="id_order" id="id_order" value="<?= $row["id_order"]; ?>">
                                                        <input class="form-control" type="file" id="image" name="image" placeholder="Upload gambar desain lampu">
                                                    </div>
                                                    <p>Apakah anda yakin ingin mengupdate status ?</p>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
                                                    <button type="submit" class="btn btn-primary" data>Konfirmasi</button=>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            <?php $i++;
                            endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</main>

<?= $this->endsection(); ?>