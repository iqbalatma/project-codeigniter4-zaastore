<?php echo $this->extend("template_dashboard/layout");
echo $this->section("content");
?>

<main>
    <div class="container-fluid px-4">
        <!-- Judul Konten -->
        <h1 class="mt-4 mb-4"><?= $title; ?></h1>
        <!-- Tutup judul konten -->


        <!-- Flash data -->
        <?php
        if ($flashdata != null) {
            echo $flashdata;
        }; ?>
        <!-- tutup flash data -->





        <!-- ROW 1 -->
        <div class="row mb-3">


            <div class="col-xl-4 col-md-4">



                <!-- Button trigger modal -->
                <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal">
                    Tambah Akun
                </button>
                <!-- Tutup button trigger modal -->




                <!-- Modal Tambah Akun-->
                <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel">Tambahkan Akun</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <form class="row g-3" method="POST" action="/registration-account">
                                <div class="modal-body">
                                    <div class="col-md-12">
                                        <label for="fullname" class="form-label">Nama Lengkap</label>
                                        <input type="text" class="form-control" id="fullname" name="fullname">
                                    </div>
                                    <div class="col-md-12">
                                        <label for="username" class="form-label">Username</label>
                                        <input type="text" class="form-control" id="username" name="username">
                                    </div>
                                    <div class="col-md-12">
                                        <label for="password" class="form-label">Password</label>
                                        <input type="password" class="form-control" id="password" name="password">
                                    </div>
                                    <div class="col-md-12">
                                        <label for="phonenumber" class="form-label">Nomor Hp</label>
                                        <input type="text" class="form-control" id="phonenumber" name="phonenumber">
                                    </div>
                                    <div class="col-md-4">

                                        <label for="id_role" class="form-label">State</label>
                                        <select id="id_role" name="id_role" class="form-select">
                                            <option selected disabled>Pilih Role</option>
                                            <?php foreach ($role as $row) : ?>
                                                <option value="<?= $row["id_role"]; ?>"><?= ucwords($row["role_name"]); ?>
                                                </option>
                                            <?php endforeach; ?>
                                        </select>

                                    </div>



                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
                                    <button type="submit" class="btn btn-primary">Daftarkan</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <!-- Tutup modal tambah akun -->



            </div>



        </div>
        <!-- TUTUP ROW 1 -->










        <!-- ROW 2 -->
        <div class="row">

            <!-- COL1 -->
            <div class="col-xl-12 col-md-12">


                <!-- BUKA TABLE RESPONSIVE -->
                <div class="table-responsive">
                    <table class="table table-dark table-striped" id="myTable">


                        <thead>
                            <tr>
                                <th scope="col">No</th>
                                <th scope="col">Nama Pengguna</th>
                                <th scope="col">Username</th>
                                <th scope="col">Password</th>
                                <th scope="col">Nomor HP</th>
                                <th scope="col">Role</th>
                                <th scope="col">Status Aktif</th>
                                <th scope="col">Aksi</th>
                            </tr>
                        </thead>


                        <tbody>
                            <?php
                            $i = 1;
                            foreach ($users as $row) :
                                $is_deleted = $row["is_deleted"];
                            ?>
                                <tr>
                                    <td><?= $i; ?></td>
                                    <td><?= ucwords($row["fullname"]); ?></td>
                                    <td><?= ($row["username"]); ?></td>
                                    <td><?= ($row["password"]); ?></td>
                                    <td><?= ($row["phonenumber"]); ?></td>
                                    <td><?= ucwords($row["role_name"]); ?></td>
                                    <td>
                                        <?php
                                        if ($is_deleted == 1) {
                                            echo "Tidak Aktif";
                                        } else {
                                            echo "Aktif";
                                        }
                                        ?></td>
                                    <td>


                                        <!-- Button Modal Edit List Akun -->
                                        <button type="button" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#edit_akun<?= $row["id_user"] ?>">
                                            <i class="fas fa-edit">
                                            </i>
                                        </button>
                                        <!-- Tutup Button Modal Edit List Akun -->


                                        <!-- Modal edit akun -->
                                        <div class="modal fade text-black" id="edit_akun<?= $row["id_user"] ?>" tabindex="-1" aria-labelledby="edit_akun<?= $row["id_user"] ?>" aria-hidden="true">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="edit_akun<?= $row["id_user"] ?>">Edit Akun</h5>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                    </div>

                                                    <form class="row g-3" method="POST" action="/edit-account">
                                                        <div class="modal-body">


                                                            <input type="hidden" class="form-control" id="id_user" name="id_user" value="<?= $row["id_user"]; ?>">


                                                            <div class="col-md-12">
                                                                <label for="fullname" class="form-label">Nama Lengkap</label>
                                                                <input type="text" class="form-control" id="fullname" name="fullname" value="<?= $row["fullname"]; ?>">
                                                            </div>


                                                            <div class="col-md-12">
                                                                <label for="username" class="form-label">Username</label>
                                                                <input type="text" class="form-control" id="username" name="username" value="<?= $row["username"]; ?>">
                                                            </div>


                                                            <div class=" col-md-12">
                                                                <label for="password" class="form-label">Password</label>
                                                                <input type="password" class="form-control" id="password" name="password" value="<?= $row["password"]; ?>">
                                                            </div>


                                                            <div class="col-md-12">
                                                                <label for="phonenumber" class="form-label">Nomor Hp</label>
                                                                <input type="text" class="form-control" id="phonenumber" name="phonenumber" value="<?= $row["phonenumber"]; ?>">
                                                            </div>


                                                            <div class="col-md-4">
                                                                <label for="id_role" class="form-label">Role </label>
                                                                <select id="id_role" name="id_role" class="form-select">
                                                                    <option selected disabled>Pilih Role</option>
                                                                    <?php foreach ($role as $row2) :
                                                                        if ($row["id_role"] == $row2["id_role"]) {
                                                                    ?>
                                                                            <option selected value="<?= $row2["id_role"]; ?>"><?= ucwords($row2["role_name"]); ?>
                                                                            </option>
                                                                        <?php
                                                                        } else {
                                                                        ?>
                                                                            <option value="<?= $row2["id_role"]; ?>"><?= ucwords($row2["role_name"]); ?>
                                                                            </option>
                                                                    <?php
                                                                        }
                                                                    endforeach; ?>
                                                                </select>
                                                            </div>


                                                            <div class="col-md-4">
                                                                <label for="is_deleted" class="form-label">Status Aktif</label>
                                                                <select id="is_deleted" name="is_deleted" class="form-select">
                                                                    <?php if ($row["is_deleted"] == 1) {
                                                                    ?>
                                                                        <option value="0">Aktif</option>
                                                                        <option selected value="1">Tidak Aktif</option>
                                                                    <?php
                                                                    } else {
                                                                    ?>
                                                                        <option selected value="0">Aktif</option>
                                                                        <option value="1">Tidak Aktif</option>
                                                                    <?php
                                                                    } ?>
                                                                </select>
                                                            </div>



                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
                                                            <button type="submit" class="btn btn-primary">Simpan</button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- Tutup Modal edit akun -->


                                    </td>
                                </tr>

                            <?php
                                $i++;
                            endforeach; ?>
                        </tbody>


                    </table>
                </div>
                <!-- TUTUP TABLE RESPONSIVE -->


            </div>
            <!-- TUTUP COL1 -->


        </div>
        <!-- TUTUP ROW 2 -->


    </div>
</main>

<?= $this->endsection(); ?>