<?= $this->extend("template_dashboard/layout"); ?>
<?= $this->section("content"); ?>
<main>
    <div class="container-fluid px-4">
        <h1 class="mt-4 mb-4"><?= $title; ?></h1>
        <?php
        if ($flashdata != null) {
            echo $flashdata;
        }; ?>
        <div class="row">
            <div class="col-xl-12 col-md-12">
                <h3>Belum Lunas</h3>
                <!-- <a href="<?php //echo base_url("PDF/print_pdf?title=Pembayaran Belum Lunas&view=pdf_payment_belum_lunas");  -->
                                ?>" class="btn btn-primary mb-3">Cetak PDF Belum Lunas</a>-->
                <div class="table-responsive">
                    <table class="table table-dark table-striped" id="myTable">
                        <thead>
                            <tr>
                                <th scope="col">No</th>
                                <th scope="col">Kode Order</th>
                                <th scope="col">Faktur</th>
                                <th scope="col">Note Tambahan</th>
                                <th scope="col">Project By</th>
                                <th scope="col">Total Tagihan</th>
                                <th scope="col">Sisa Bayar</th>
                                <th scope="col">Proses</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $i = 1;
                            $total_price_sum = 0;
                            foreach ($order_data_on_progress as $row) :

                                // echo $row["id_order"];

                                $price = $row["price"];
                                $total_price = $row["total_price"] + intval($row["installation_price"]);


                                $payment_left =  $payment->where("id_order", $row["id_order"])->orderBy("date_payment", "desc")->findAll()[0]["payment_left"];
                                // var_dump($payment->where("id_order", $row["id_order"])->orderBy("date_payment", "desc")->findAll());
                                // $payment_left = 10;

                                if ($payment_left > 0) {

                                    $total_price_sum += $payment_left;


                            ?>
                                    <tr class="table-danger">
                                        <th scope="row"><?= $i; ?></th>
                                        <td><?= $row["order_code"]; ?></td>
                                        <td><?= $row["faktur_code"]; ?></td>
                                        <td><?= $row["notes"]; ?></td>
                                        <td><?= $row["fullname"]; ?></td>

                                        <td>Rp <?= number_format($total_price, 0, ',', '.');
                                                $price; ?></td>


                                        <td>Rp <?= number_format($payment_left, 0, ',', '.'); ?></td>

                                        <!-- Button trigger modal -->
                                        <td>

                                            <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#history_pembayaran1<?= $row['id_order'] ?>">
                                                <i class="fas fa-clipboard-list"></i>
                                            </button>


                                            <!-- Modal -->
                                            <div class="modal fade" id="history_pembayaran1<?= $row['id_order'] ?>" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="history_pembayaran1<?= $row['id_order'] ?>Label" aria-hidden="true">
                                                <div class="modal-dialog modal-lg">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title" id="history_pembayaran1<?= $row['id_order'] ?>Label">History Pembayaran</h5>
                                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                        </div>
                                                        <div class="modal-body">
                                                            <?php

                                                            $history_payment = $payment->where("id_order", $row["id_order"])->where("is_deleted", 0)->findAll();

                                                            ?>


                                                            <div class="table-responsive">
                                                                <table class="table">
                                                                    <thead>
                                                                        <tr>
                                                                            <th scope="col">No</th>
                                                                            <th scope="col">Pembayaran</th>
                                                                            <th scope="col">Sisa Bayar</th>
                                                                            <th scope="col">Tanggal</th>
                                                                            <th scope="col">Bukti Bayar</th>

                                                                        </tr>
                                                                    </thead>
                                                                    <tbody>
                                                                        <?php
                                                                        $j = 1;
                                                                        foreach ($history_payment as $row2) : ?>
                                                                            <tr>
                                                                                <th scope="row"><?= $j; ?></th>
                                                                                <td>Rp <?= number_format($row2["paid_amount"], 0, ',', '.'); ?></td>
                                                                                <td>Rp <?= number_format($row2["payment_left"], 0, ',', '.'); ?></td>
                                                                                <td><?= $row2["date_payment"]; ?></td>
                                                                                <td>
                                                                                    <?php if ($row2["image_payment"] !== null) {
                                                                                    ?>

                                                                                        <a type="button" data-bs-toggle="modal" data-bs-target="#modal_payment_image<?= $row2["id_payment"] ?>"><img src="<?= base_url("/uploads/bukti_bayar") . "/" . $row2["image_payment"]; ?>" style="height: 100px;"></a>

                                                                                        <!-- Modal -->
                                                                                        <div class="modal fade" id="modal_payment_image<?= $row2["id_payment"] ?>" tabindex="-1" aria-labelledby="modal_payment_image<?= $row2["id_payment"] ?>Label" aria-hidden="true">
                                                                                            <div class="modal-dialog modal-xl">
                                                                                                <div class="modal-content">
                                                                                                    <div class="modal-header">
                                                                                                        <h5 class="modal-title" id="exampleModalLabel">Bukti Bayar</h5>
                                                                                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                                                                    </div>
                                                                                                    <div class="modal-body">
                                                                                                        <img src="<?= base_url("/uploads/bukti_bayar") . "/" . $row2["image_payment"]; ?>" style="width: 1000px;">
                                                                                                    </div>
                                                                                                    <div class="modal-footer">
                                                                                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </div>



                                                                                    <?php
                                                                                    }; ?>
                                                                                </td>
                                                                            </tr>
                                                                        <?php

                                                                            $j++;
                                                                        endforeach; ?>

                                                                    </tbody>
                                                                </table>
                                                            </div>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#transaksi_pembayaran<?= $row['id_order'] ?>">
                                                <i class="fas fa-money-bill-wave"></i>
                                            </button>
                                            <!-- Modal -->
                                            <div class="modal fade" id="transaksi_pembayaran<?= $row['id_order'] ?>" tabindex="-1" aria-labelledby="transaksi_pembayaran<?= $row['id_order'] ?>Label" aria-hidden="true">
                                                <div class="modal-dialog modal-lg">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title" id="transaksi_pembayaran<?= $row['id_order'] ?>Label">Transaksi Pembayaran | Sisa Bayar Rp <?= number_format($payment_left, 0, ',', '.'); ?></h5>
                                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                        </div>
                                                        <form action="/payment-transaction" method="POST" enctype="multipart/form-data">
                                                            <div class="modal-body">


                                                                <input type="hidden" name="id_order" id="id_order" value="<?= $row["id_order"]; ?>">
                                                                <div class="row">
                                                                    <label for="basic-url" class="form-label">Tambahkan Pembayaran</label>
                                                                    <div class="col-md-8">
                                                                        <div class="input-group mb-3">
                                                                            <span class="input-group-text" id="basic-addon3"><?= $row["order_code"]; ?></span>
                                                                            <input type="text" class="form-control" id="paid_amount<?= $row['order_code'] ?>" name="paid_amount" aria-describedby="basic-addon3">
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-md-4">
                                                                        <div class="form-check">
                                                                            <input class="form-check-input" type="checkbox" id="lunas<?= $row['order_code'] ?>" name="lunas" onclick="myFunctionLunas(<?= $payment_left ?>, '<?= $row['order_code'] ?>')">
                                                                            <label class="form-check-label" for="lunas">
                                                                                Lunas
                                                                            </label>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-md-12 mb-3">
                                                                        <label for="image_payment" class="form-label">Upload Bukti Pembayaran (Optional)</label>
                                                                        <input class="form-control" type="file" id="image_payment" name="image_payment" placeholder="Upload bukti pembayaran">
                                                                    </div>

                                                                </div>
                                                            </div>
                                                            <div class="modal-footer">
                                                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                                                <button type="submit" class="btn btn-primary">Save changes</button>


                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                            <?php
                                    $i++;
                                }
                            endforeach; ?>


                            <script>
                                function myFunctionLunas(payment_left, order_code) {
                                    console.log("lunas" + order_code)
                                    var checkBox = document.getElementById("lunas" + order_code);


                                    if (checkBox.checked == true) {
                                        document.getElementById("paid_amount" + order_code).setAttribute('value', payment_left);
                                        document.getElementById("paid_amount" + order_code).readOnly = true;
                                    } else {
                                        document.getElementById("paid_amount" + order_code).readOnly = false;
                                        document.getElementById("paid_amount" + order_code).setAttribute('value', '');
                                    }
                                }
                            </script>

                        </tbody>
                    </table>
                </div>




                <!-- SEPARATOR -->
                <br><br>
                <form action="/payment/payment-this-month" method="GET">
                    <div class="row mb-4">
                        <div class="col-xl-4 col-md-4">
                            <select class="form-select" aria-label="Default select example" name="month">
                                <option selected disabled>Pilih Bulan Untuk Filter</option>
                                <option value="1">Januari</option>
                                <option value="2">Februari</option>
                                <option value="3">Maret</option>
                                <option value="4">April</option>
                                <option value="5">Mei</option>
                                <option value="6">Juni</option>
                                <option value="7">Juli</option>
                                <option value="8">Agustus</option>
                                <option value="9">September</option>
                                <option value="10">Oktober</option>
                                <option value="11">November</option>
                                <option value="12">Desember</option>
                            </select>
                        </div>
                        <div class="col-xl-4 col-md-4">
                            <select class="form-select" aria-label="Default select example" name="year">
                                <option selected>Pilih Tahun Untuk Filter</option>
                                <?php $counter_year = 2021;
                                while ($counter_year < 2030) {
                                ?>
                                    <option value="<?= $counter_year; ?>"><?= $counter_year; ?></option>
                                <?php
                                    $counter_year++;
                                }
                                ?>
                            </select>
                        </div>
                        <div class="col-xl-4 col-md-4">
                            <input class="btn btn-primary" type="submit" value="Filter">
                            <?php if ($data_type == "payment-this-month") {
                            ?>
                                <a href="/payment/payment-all" class="btn btn-primary">Tampilkan Semua Data</a>

                                <!-- Button trigger modal -->
                                <!-- <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal">
                                    Cetak PDF Data Lunas Perbulan
                                </button> -->

                            <?php
                            } else {
                            ?>
                                <a href="/payment/payment-this-month" class="btn btn-primary">Tampilkan Data Bulan Ini</a>
                                <!-- <a href="<?php //echo base_url("PDF/print_pdf?title=Pembayaran Lunas&view=pdf_payment&data_type=payment_all");  -->
                                                ?>" class="btn btn-primary">Cetak PDF Seluruh Data Lunas</a>-->
                            <?php
                            } ?>
                        </div>
                    </div>
                </form>

                <!-- Modal -->
                <!-- <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel">Cetak PDF Data Lunas Perbulan</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                <form action="<?= base_url("PDF/print_pdf?title=Pembayaran Lunas&view=pdf_payment&data_type=payment_this_month"); ?>" method="GET">
                                    <div class="row mb-4">
                                        <input type="hidden" name="title" value="Pembayaran Lunas">
                                        <input type="hidden" name="view" value="pdf_payment">
                                        <input type="hidden" name="data_type" value="payment_this_month">


                                        <div class="col-xl-6 col-md-6">
                                            <select class="form-select" aria-label="Default select example" name="month">
                                                <option selected disabled>Pilih Bulan Untuk Filter</option>
                                                <option value="1">Januari</option>
                                                <option value="2">Februari</option>
                                                <option value="3">Maret</option>
                                                <option value="4">April</option>
                                                <option value="5">Mei</option>
                                                <option value="6">Juni</option>
                                                <option value="7">Juli</option>
                                                <option value="8">Agustus</option>
                                                <option value="9">September</option>
                                                <option value="10">Oktober</option>
                                                <option value="11">November</option>
                                                <option value="12">Desember</option>
                                            </select>
                                        </div>
                                        <div class="col-xl-6 col-md-6">
                                            <select class="form-select" aria-label="Default select example" name="year">
                                                <option selected>Pilih Tahun Untuk Filter</option>
                                                <?php $counter_year = 2021;
                                                while ($counter_year < 2030) {
                                                ?>
                                                    <option value="<?= $counter_year; ?>"><?= $counter_year; ?></option>
                                                <?php
                                                    $counter_year++;
                                                }
                                                ?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
                                        <button type="submit" class="btn btn-primary">Cetak PDF</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div> -->

                <h3>Sudah Lunas</h3>
                <div class="table-responsive">
                    <table class="table table-dark table-striped" id="myTable2">
                        <thead>
                            <tr>
                                <th scope="col">No</th>
                                <th scope="col">Kode Order</th>
                                <th scope="col">Faktur</th>
                                <th scope="col">Note Tambahan</th>
                                <th scope="col">Tanggal Lunas</th>
                                <th scope="col">Project By</th>
                                <th scope="col">Total Tagihan</th>
                                <th scope="col">Sisa Bayar</th>

                                <th scope="col">Proses</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $i = 1;
                            $total_price_sum = 0;
                            foreach ($order_data as $row) :

                                $price = $row["price"];
                                $total_price = $row["total_price"] + intval($row["installation_price"]);;

                                $payment_left  = $payment->where("id_order", $row["id_order"])->orderBy("date_payment", "desc")->findAll()[0]["payment_left"];

                                if ($payment_left <= 0) {
                                    $payment_left = 0;
                                    $total_price_sum += $total_price;


                            ?>
                                    <tr class="table-success">
                                        <th scope="row"><?= $i; ?></th>
                                        <td><?= $row["order_code"]; ?></td>
                                        <td><?= $row["faktur_code"]; ?></td>
                                        <td><?= $row["notes"]; ?></td>
                                        <td><?= $row["date_paid_off"]; ?></td>
                                        <td><?= $row["fullname"]; ?></td>

                                        <td>Rp <?= number_format($total_price, 0, ',', '.'); ?></td>


                                        <td>Rp <?= number_format($payment_left, 0, ',', '.'); ?></td>



                                        <!-- Button trigger modal -->
                                        <td>
                                            <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#history_pembayaran1<?= $row['id_order'] ?>">
                                                <i class="fas fa-clipboard-list"></i>
                                            </button>


                                            <!-- Modal -->
                                            <div class="modal fade" id="history_pembayaran1<?= $row['id_order'] ?>" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="history_pembayaran1<?= $row['id_order'] ?>Label" aria-hidden="true">
                                                <div class="modal-dialog modal-lg">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title" id="history_pembayaran1<?= $row['id_order'] ?>Label">History Pembayaran</h5>
                                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                        </div>
                                                        <div class="modal-body">
                                                            <?php

                                                            $history_payment = $payment->where("id_order", $row["id_order"])->where("is_deleted", 0)->findAll();

                                                            ?>


                                                            <div class="table-responsive">
                                                                <table class="table">
                                                                    <thead>
                                                                        <tr>
                                                                            <th scope="col">No</th>
                                                                            <th scope="col">Pembayaran</th>
                                                                            <th scope="col">Sisa Bayar</th>
                                                                            <th scope="col">Tanggal</th>
                                                                            <th scope="col">Bukti Bayar</th>

                                                                        </tr>
                                                                    </thead>
                                                                    <tbody>
                                                                        <?php
                                                                        $j = 1;
                                                                        foreach ($history_payment as $row2) : ?>
                                                                            <tr>
                                                                                <th scope="row"><?= $j; ?></th>
                                                                                <td>Rp <?= number_format($row2["paid_amount"], 0, ',', '.'); ?></td>
                                                                                <td>Rp <?= number_format($row2["payment_left"], 0, ',', '.'); ?></td>
                                                                                <td><?= $row2["date_payment"]; ?></td>
                                                                                <td>
                                                                                    <?php if ($row2["image_payment"] !== null) {
                                                                                    ?>

                                                                                        <a type="button" data-bs-toggle="modal" data-bs-target="#modal_payment_image<?= $row2["id_payment"] ?>"><img src="<?= base_url("/uploads/bukti_bayar") . "/" . $row2["image_payment"]; ?>" style="height: 100px;"></a>

                                                                                        <!-- Modal -->
                                                                                        <div class="modal fade" id="modal_payment_image<?= $row2["id_payment"] ?>" tabindex="-1" aria-labelledby="modal_payment_image<?= $row2["id_payment"] ?>Label" aria-hidden="true">
                                                                                            <div class="modal-dialog modal-xl">
                                                                                                <div class="modal-content">
                                                                                                    <div class="modal-header">
                                                                                                        <h5 class="modal-title" id="exampleModalLabel">Bukti Bayar</h5>
                                                                                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                                                                    </div>
                                                                                                    <div class="modal-body">
                                                                                                        <img src="<?= base_url("/uploads/bukti_bayar") . "/" . $row2["image_payment"]; ?>" style="width: 1000px;">
                                                                                                    </div>
                                                                                                    <div class="modal-footer">
                                                                                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </div>



                                                                                    <?php
                                                                                    }; ?>
                                                                                </td>
                                                                            </tr>
                                                                        <?php

                                                                            $j++;
                                                                        endforeach; ?>

                                                                    </tbody>
                                                                </table>
                                                            </div>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </td>


                                    </tr>





                            <?php
                                    $i++;
                                }
                            endforeach; ?>
                            <tr>
                                <td colspan="5">Jumlah Harga Barang</td>
                                <td></td>
                                <td>
                                    Rp <?= number_format($total_price_sum, 0, ',', '.') ?>
                                </td>
                                <td></td>
                                <td></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>




    </div>
</main>

<?= $this->endsection(); ?>