<?= $this->extend("template_dashboard/layout"); ?>
<?= $this->section("content"); ?>

<main>
    <div class="container-fluid px-4">
        <!-- title -->
        <h1 class="mt-4 mb-4"><?= $title; ?></h1>
        <!-- tutup title -->

        <!-- flashdata -->
        <?php
        if ($flashdata != null) {
            echo $flashdata;
        }; ?>
        <!-- tutup flash data -->


        <!-- ROW 1 -->
        <hr>
        <h3>Penugasan Pembuatan Lampu</h3>
        <div class="row">
            <div class="col-xl-12 col-md-12">

                <!-- Buka table -->
                <div class="table-responsive">
                    <table class="table table-dark table-striped" id="myTable">


                        <thead>
                            <tr>
                                <th scope="col">No</th>
                                <th scope="col">Kode Order</th>
                                <th scope="col">Tanggal Pesan</th>
                                <th scope="col">Tanggal Deadline</th>
                                <th scope="col">Font</th>
                                <th scope="col">Ukuran Akrilik</th>
                                <th scope="col">Panjang Kabel</th>
                                <th scope="col">Adaptor</th>
                                <th scope="col">Komponen Tambahan</th>
                                <th scope="col">Catatan Desain</th>
                                <th scope="col">Gambar Desain</th>
                                <th scope="col">Proses</th>
                            </tr>
                        </thead>


                        <tbody>
                            <?php $i = 1;
                            foreach ($assignment as $row) :
                                //memisahkan tanggal dengan jam
                                $order_date = $row["order_date"];
                                $order_date = explode(" ", $order_date);
                                $order_date = $order_date[0];

                                //memisahkan tanggal dengan jam
                                $deadline_date = $row["deadline"];
                                $deadline_date = explode(" ", $deadline_date);
                                $deadline_date = $deadline_date[0];


                                $file_array = $image_design->where("is_deleted", 0)->where("id_order", $row["id_order"])->findAll();
                            ?>
                                <tr>
                                    <th scope="row"><?= $i; ?></th>
                                    <td><?= $row["order_code"]; ?></td>
                                    <td><?= $order_date; ?></td>
                                    <td><?= $deadline_date ?></td>
                                    <td><?= $row["font"] ?></td>
                                    <td><?= $row["size_acrilic"] ?></td>
                                    <td><?= $row["cable_length"] ?></td>
                                    <td><?= $row["adaptor"] ?></td>
                                    <td>
                                        <?php if ($row["waterproof"] != null) {
                                            echo "Waterproof, ";
                                            echo "<br>";
                                        }
                                        if ($row["adhesive"] != null) {
                                            echo "Perekat =  " . $row['adhesive'] . ",";
                                            echo "<br>";
                                        }
                                        if ($row["switch"] != null) {
                                            echo "Saklar = " . $row['switch'] . ",";
                                            echo "<br>";
                                        }
                                        if ($row["laser_cut"] != null) {
                                            echo "Laser Cut,";
                                            echo "<br>";
                                        }
                                        if ($row["peniklan"] != null) {
                                            echo "Peniklan = " . $row['peniklan'];
                                            echo "<br>";
                                        }
                                        ?>
                                    </td>
                                    <td><?= $row["design_notes"] ?></td>
                                    <td>
                                        <a type="button" class="" data-bs-toggle="modal" data-bs-target="#modal_design_technician<?= $row['id_order'] ?>">
                                            <?php if (count($file_array) > 0) {
                                            ?>
                                                <img src="<?= base_url("/uploads/desain") . "/" . $file_array[0]["image_name"]; ?>" style="height: 100px;">
                                            <?php
                                            } else {
                                            ?>
                                                <img src="/assets/img/default.png" style="height: 100px;">

                                            <?php
                                            }; ?>
                                        </a>
                                    </td>
                                    <td>
                                        <a type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modal_technician_assignment<?= $row['id_order'] ?>">
                                            <i class="fas fa-user-check"></i>
                                        </a>
                                    </td>
                                </tr>

                                <!-- Modal Detail Image-->
                                <div class="modal fade" id="modal_design_technician<?= $row['id_order'] ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                    <div class="modal-dialog modal-dialog-centered modal-xl">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="exampleModalLabel">Gambar Desain Lampu</h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body">

                                                <div class="row row-cols-1 row-cols-md-3 g-4">

                                                    <?php
                                                    $counter_array = 0;
                                                    while ($counter_array < count($file_array)) {
                                                    ?>
                                                        <div class="col">
                                                            <div class="card h-100">
                                                                <img src="<?= base_url("/uploads/desain") . "/" . $file_array[$counter_array]["image_name"]; ?>">
                                                                <div class="card-body">
                                                                    <a href="<?= base_url("/uploads/desain") . "/" . $file_array[$counter_array]["image_name"]; ?>" download type="button" class="mt-3 btn btn-success">Download Gambar</a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    <?php
                                                        $counter_array++;
                                                    }

                                                    ?>
                                                </div>

                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- Close, Modal Detail Image-->


                                <!-- Modal Technician Assignment -->
                                <div class="modal fade" id="modal_technician_assignment<?= $row['id_order'] ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                    <div class="modal-dialog modal-dialog-centered">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="exampleModalLabel">Penugasan Teknisi</h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                            </div>
                                            <form action="/assignment-to-technician" method="POST">
                                                <div class="modal-body">

                                                    <!-- id order -->
                                                    <input type="hidden" name="id_order" id="id_order" value="<?= $row["id_order"]; ?>">


                                                    <!-- id_technician didapat pada id_user -->
                                                    <label for="technician" class="form-label">Pilih Teknisi</label>
                                                    <select class="form-select" aria-label="Default select example" id="technician" name="technician">
                                                        <?php foreach ($technician as $row_technician) : ?>
                                                            <option value="<?= $row_technician["id_user"]; ?>"><?= $row_technician["fullname"]; ?></option>
                                                        <?php endforeach; ?>
                                                    </select>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
                                                    <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Submit</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                                <!-- Close, Modal technician Assignment -->


                            <?php $i++;
                            endforeach; ?>
                        </tbody>


                    </table>
                </div>
                <!-- tutup table -->


            </div>
        </div>
        <!-- TUTUP ROW 1 -->




        <!-- ROW 2 -->
        <hr>
        <h3>Penugasan Pemasangan</h3>
        <div class="row">
            <div class="col-xl-12 col-md-12">

                <!-- Buka table -->
                <div class="table-responsive">
                    <table class="table table-dark table-striped" id="myTable2">


                        <thead>
                            <tr>
                                <th scope="col">No</th>
                                <th scope="col">Kode Order</th>
                                <th scope="col">Tanggal Pesan</th>
                                <th scope="col">Tanggal Deadline</th>
                                <th scope="col">Font</th>
                                <th scope="col">Ukuran Akrilik</th>
                                <th scope="col">Panjang Kabel</th>
                                <th scope="col">Adaptor</th>
                                <th scope="col">Komponen Tambahan</th>
                                <th scope="col">Catatan Desain</th>
                                <th scope="col">Harga Pemasangan</th>
                                <th scope="col">Fee Pemasangan</th>
                                <th scope="col">Gambar Desain</th>
                                <th scope="col">Proses</th>
                            </tr>
                        </thead>


                        <tbody>
                            <?php $i = 1;
                            foreach ($assignment_installation as $row2) :
                                //memisahkan tanggal dengan jam
                                $order_date = $row2["order_date"];
                                $order_date = explode(" ", $order_date);
                                $order_date = $order_date[0];

                                //memisahkan tanggal dengan jam
                                $deadline_date = $row2["deadline"];
                                $deadline_date = explode(" ", $deadline_date);
                                $deadline_date = $deadline_date[0];

                                //memisahkan gambar jadi array
                                $file_array = $image_design->where("is_deleted", 0)->where("id_order", $row2["id_order"])->findAll();

                                $fee_installation = 0.3 * $row2["installation_price"];
                            ?>
                                <tr>
                                    <th scope="row2"><?= $i; ?></th>
                                    <td><?= $row2["order_code"]; ?></td>
                                    <td><?= $order_date; ?></td>
                                    <td><?= $deadline_date ?></td>
                                    <td><?= $row2["font"] ?></td>
                                    <td><?= $row2["size_acrilic"] ?></td>
                                    <td><?= $row2["cable_length"] ?></td>
                                    <td><?= $row2["adaptor"] ?></td>
                                    <td>
                                        <?php if ($row2["waterproof"] != null) {
                                            echo "Waterproof, ";
                                            echo "<br>";
                                        }
                                        if ($row2["adhesive"] != null) {
                                            echo "Perekat =  " . $row2['adhesive'] . ",";
                                            echo "<br>";
                                        }
                                        if ($row2["switch"] != null) {
                                            echo "Saklar = " . $row2['switch'] . ",";
                                            echo "<br>";
                                        }
                                        if ($row2["laser_cut"] != null) {
                                            echo "Laser Cut,";
                                            echo "<br>";
                                        }
                                        if ($row2["peniklan"] != null) {
                                            echo "Peniklan = " . $row2['peniklan'];
                                            echo "<br>";
                                        }
                                        ?>
                                    </td>
                                    <td><?= $row2["design_notes"] ?></td>
                                    <td><?= "Rp " . number_format($row2["installation_price"], 0, ',', '.'); ?></td>
                                    <td><?= "Rp " . number_format($fee_installation, 0, ',', '.'); ?></td>
                                    <td>

                                        <a type="button" class="" data-bs-toggle="modal" data-bs-target="#modal_design_installation<?= $row2['id_order'] ?>">
                                            <?php if (count($file_array) > 0) {
                                            ?>
                                                <img src="<?= base_url("/uploads/desain") . "/" . $file_array[0]["image_name"]; ?>" style="height: 100px;">
                                            <?php
                                            } else {
                                            ?>
                                                <img src="/assets/img/default.png" style="height: 100px;">

                                            <?php
                                            }; ?>
                                        </a>
                                    </td>
                                    <td>
                                        <a type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modal_installation_assignment<?= $row2['id_order'] ?>">
                                            <i class="fas fa-user-check"></i>
                                        </a>
                                    </td>
                                </tr>

                                <!-- Modal Detail Image-->
                                <div class="modal fade" id="modal_design_installation<?= $row2['id_order'] ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                    <div class="modal-dialog modal-dialog-centered modal-xl">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="exampleModalLabel">Gambar Desain Lampu</h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body">
                                                <div class="row row-cols-1 row-cols-md-3 g-4">

                                                    <?php
                                                    $counter_array = 0;
                                                    while ($counter_array < count($file_array)) {
                                                    ?>
                                                        <div class="col">
                                                            <div class="card h-100">
                                                                <img src="<?= base_url("/uploads/desain") . "/" . $file_array[$counter_array]["image_name"]; ?>">
                                                                <div class="card-body">
                                                                    <a href="<?= base_url("/uploads/desain") . "/" . $file_array[$counter_array]["image_name"]; ?>" download type="button" class="mt-3 btn btn-success">Download Gambar</a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    <?php
                                                        $counter_array++;
                                                    }

                                                    ?>
                                                </div>

                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- Close, Modal Detail Image-->


                                <!-- Modal Technician Assignment -->
                                <div class="modal fade" id="modal_installation_assignment<?= $row2['id_order'] ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                    <div class="modal-dialog modal-dialog-centered">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="exampleModalLabel">Penugasan Pemasangan</h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                            </div>
                                            <form action="/assignment-to-installation" method="POST">
                                                <div class="modal-body">

                                                    <!-- id order -->
                                                    <input type="hidden" name="id_order" id="id_order" value="<?= $row2["id_order"]; ?>">


                                                    <!-- id_technician didapat pada id_user -->
                                                    <label for="technician" class="form-label">Pilih Teknisi</label>
                                                    <select class="form-select" aria-label="Default select example" id="installer" name="installer">
                                                        <?php foreach ($technician as $row2_technician) : ?>
                                                            <option value="<?= $row2_technician["id_user"]; ?>"><?= $row2_technician["fullname"]; ?></option>
                                                        <?php endforeach; ?>
                                                    </select>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
                                                    <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Submit</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                                <!-- Close, Modal technician Assignment -->


                            <?php $i++;
                            endforeach; ?>
                        </tbody>


                    </table>
                </div>
                <!-- tutup table -->


            </div>
        </div>
        <!-- TUTUP ROW 2 -->



    </div>
</main>

<?= $this->endsection(); ?>