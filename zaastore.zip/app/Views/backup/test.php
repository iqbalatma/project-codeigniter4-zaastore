<?php

var_dump($errors);
