<?php
require("header.php");
require("navbar.php");
require("sidebar.php");
echo view($content);
require("footer.php");
